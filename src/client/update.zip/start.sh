#!/bin/bash

npm start